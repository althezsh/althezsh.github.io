# Rabbit House

## 起源 [tedezarize.com](http://tedezarize.com)

只是因为很有趣  
* 天天座理世 `tedezarize.com` 起源  
* 保登心爱 `hotococoa.com` 已加入  
* 间桐纱路 `kirimasharo.com` 已加入 
* 宇治松千夜 `ujimatsuchiya.com` 已加入 
* 香风智乃 `kafuuchino.com` 联系不上  
 

*** 
## 使用 
看js源码可以打开rabbit_demo.js 
页脚的图片顺序是按动画出场顺序  
 
需要Google-analytics 去backups文件夹取吧 我们都没用过...
 
添加不蒜子访问量计数器  
不需要的话可以在`rabbit.js`删除 
`var busuanzi = false;`  
然后重新生成min文件 
* pv 每访问一次+1
* uv 每一个用户只+1 
 
如果你是上述域名持有者 可以直接部署 js会检测你的域名   
`ico`文件夹下面对应的`<name>.ico`拿出来`index.html`同级目录  
改名为`favicon.ico`  
生成自`circle.py`有兴趣可以研究下  
 
CNAME自行修改
 
*** 
## 其他作品 
修改rabbit.js 里面的rabbit字典 重新生成一份min文件 就可以使用了   
大概...
 